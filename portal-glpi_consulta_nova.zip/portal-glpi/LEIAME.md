# Portal de Consulta de Chamados (GLPI)

Página pública, sem login, onde o usuário digita o **número do chamado** e vê o status,
as datas, o técnico e o histórico. A área **/admin** guarda a conexão com a API do GLPI
e define o que o portal mostra.

## 1. Subir o portal (HTTPS na porta 8443)

Copie a pasta `portal-glpi` para o servidor (ex.: `/opt/portal-glpi`) e rode:

```bash
cd /opt/portal-glpi
nano docker-compose.yml        # troque PORTAL_SENHA e confira PORTAL_HOSTS
docker compose up -d --build
firewall-cmd --permanent --add-port=8443/tcp --add-port=8090/tcp && firewall-cmd --reload
```

* Portal público: `https://IP_DO_SERVIDOR:8443`
* Área restrita: `https://IP_DO_SERVIDOR:8443/admin`
* A porta **8090 (HTTP)** só redireciona para o HTTPS.

### Certificado

Na primeira execução o portal gera um **certificado autoassinado** para os endereços de
`PORTAL_HOSTS` (IP e/ou nome do servidor, separados por vírgula). Ele fica em `data/certs/`.

Com certificado autoassinado, o navegador avisa **"Sua conexão não é particular"** no
primeiro acesso (Avançado > Continuar). A conexão é criptografada mesmo assim. Para tirar o
aviso:

* **Certificado da empresa (recomendado):** se houver uma autoridade certificadora interna
  (ex.: AD CS), emita um certificado para o endereço do portal e salve como
  `data/certs/cert.pem` (certificado + cadeia) e `data/certs/key.pem` (chave). Depois:
  `docker compose restart`.
* **Ou distribua o certificado gerado** (`data/certs/cert.pem`) para as máquinas da equipe,
  em "Autoridades de Certificação Raiz Confiáveis" (por GPO, por exemplo).

Mudou o IP ou o nome do servidor? Ajuste `PORTAL_HOSTS`, apague `data/certs/` e rode
`docker compose up -d` para gerar um certificado novo.

O administrador do `docker-compose.yml` é criado só na primeira execução. Depois, troque a
senha pela própria área restrita. Se perder a senha, apague `data/users.json` e rode
`docker compose restart`.

## 2. Configurar a conexão (área /admin)

| Campo | Onde encontrar no GLPI |
|---|---|
| URL da API | `https://IP_DO_GLPI/apirest.php` |
| App Token | Configurar > Geral > API > (cliente da API) |
| User Token | Minhas configurações > Chaves de acesso remoto > Token da API |

Clique em **Testar conexão** e depois em **Salvar configurações**.

Use um **usuário do GLPI só para o portal**, que enxergue todas as entidades e leia
chamados e usuários. O cliente da API precisa estar ativo e liberar o IP do servidor
do portal.

## 3. O que o portal mostra

* Sempre: número, título, status (com explicação para o usuário), datas e categoria.
* Opcional: descrição, histórico, técnico, nomes das pessoas e prazo de SLA.
* **Nunca**: acompanhamentos/tarefas privados e anexos.

## 4. Segurança

Os números dos chamados são sequenciais. Com a consulta só pelo número, quem acessa o
portal pode tentar números em sequência e ler chamados de outras pessoas. Proteções:

* **Limite de consultas por minuto por IP** (padrão 10).
* **Exigir o e-mail do requerente** junto com o número (recomendado se o portal for
  acessado fora da rede interna). O e-mail é comparado com os e-mails do usuário
  requerente no GLPI e com o e-mail alternativo do chamado.
* Chamado inexistente e e-mail errado recebem a **mesma mensagem**, para não revelar
  quais números existem.
* Revise os textos dos chamados: o que estiver em acompanhamento **público** aparece no
  portal. Informações internas devem ser registradas como **privadas** no GLPI.

Se o portal ficar atrás de um proxy reverso, adicione no `docker-compose.yml` a variável
`FORWARDED_ALLOW_IPS=IP_DO_PROXY`. Assim o limite por IP passa a usar o IP real do
visitante (cabeçalho X-Forwarded-For), e não o IP do proxy.

## 5. Área de atendimento dos técnicos

Em `/admin`, os técnicos entram com o **usuário e a senha da rede (AD)**, os mesmos do GLPI.
O portal pede ao GLPI para fazer o login: o GLPI confere a senha nos diretórios LDAP dele e
o portal só libera quem tem um dos perfis configurados (padrão: `Technician`).

**Pré-requisito no GLPI:** Configurar > Geral > API > marque **"Habilitar login com
credenciais"**. O cliente da API usado pelo portal precisa liberar o IP do servidor do portal.

No atendimento, o técnico:

* filtra os chamados por técnico (padrão: os dele) e situação;
* abre o chamado e vê descrição e histórico completo (privados aparecem marcados);
* usa **"Associar a mim mesmo"** para se colocar como técnico atribuído (como no GLPI).
  Para achar chamados ainda sem técnico, filtre **Técnico: Todos** e **Situação: Novos**;
* responde com as marcações:
  * **Colocar em pendência**: envia a resposta e deixa o chamado Pendente, aguardando o cliente;
  * **Registrar como solução**: o chamado fica Solucionado e o solicitante aprova ou recusa;
  * **Privado**: nota visível só para a equipe.

Tudo é registrado no GLPI **em nome do técnico**, com as permissões do perfil dele.
O administrador local do portal continua entrando só nas configurações.

**Segurança:** com login do AD, a senha de rede dos técnicos trafega até o portal. Por isso
o portal funciona em HTTPS (porta 8443) e os cookies de sessão só trafegam criptografados.

## 6. Área do solicitante ("Meus chamados")

Endereço: `https://IP_DO_SERVIDOR:8443/meus-chamados` (há um link na página inicial).

* Login com o **usuário e senha da rede (AD)**: o GLPI confere a senha. Entram os perfis
  listados em "Área do solicitante" no /admin (padrão: `Self-Service`).
* Cada usuário vê **só os chamados em que é requerente**, abertos nos últimos 30 dias
  (configurável), com o técnico responsável e filtros por situação.
* **Pendentes:** o usuário responde pelo portal e o chamado volta para a equipe.
* **Solucionados:** o usuário marca **"Aprovo a solução"** (o chamado é encerrado) ou
  **"Não aprovo"** (precisa dizer o motivo; o chamado é reaberto).
* Respostas e avaliações ficam registradas no GLPI **em nome do usuário**.
* Itens privados nunca aparecem. A lista mostra até os 200 chamados mais recentes.

Pré-requisitos no GLPI: "Habilitar login com credenciais" na API (o mesmo do atendimento)
e o perfil Self-Service com permissão de acompanhar e aprovar os próprios chamados.

## 7. Desempenho e robustez

* O portal roda com **vários processos** em paralelo (`PORTAL_WORKERS=4` no
  `docker-compose.yml`; use até o número de núcleos do servidor).
* Sessões, limite de tentativas de login e cache ficam em `data/compartilhado.sqlite`,
  compartilhados entre os processos. Reiniciar o portal **não** derruba os logins.
* A lista "Meus chamados" fica em cache por 30 segundos (vem sempre atualizada ao entrar,
  ao clicar em "Atualizar" e depois de cada resposta ou avaliação).
* Teste de carga (4 processos): 2.500 acessos com 100 simultâneos a ~240 por segundo, sem
  erros. O limite real costuma ser o **GLPI**, que responde a cada consulta.
* `docker ps` mostra `healthy`/`unhealthy` (checagem em `/saude`); os logs do contêiner
  ficam limitados a 3 arquivos de 10 MB.

## 8. Usar o mesmo certificado do GLPI (acesso pelo nome)

O portal está no mesmo servidor do GLPI e pode usar **o mesmo certificado**. O script
`usar-certificado-glpi.sh` copia o certificado e a chave do Apache para `data/certs`,
confere se a chave combina, se o nome `helpdesk.grupovia.lan` está no certificado e se ele
não está vencido, e reinicia o portal:

```bash
cd /opt/portal-glpi
./usar-certificado-glpi.sh
```

Por padrão ele usa `/etc/pki/tls/certs/helpdesk.crt` e `/etc/pki/tls/private/helpdesk.key`
(os arquivos que o `glpi.conf` usa hoje). Para outros arquivos, por exemplo os da CA
interna com a cadeia:

```bash
CERT=/etc/pki/tls/certs/helpdesk-ca.crt CHAVE=/etc/pki/tls/private/helpdesk-ca.key \
CADEIA=/etc/pki/tls/certs/helpdesk-cadeia.crt ./usar-certificado-glpi.sh
```

Rode de novo sempre que o certificado do GLPI for trocado ou renovado. Se algo estiver
errado, o script não altera nada e o portal continua com o certificado anterior.

Acesse por `https://helpdesk.grupovia.lan:8443`. Sem aviso nos computadores que confiam
na autoridade que emitiu o certificado (raiz do mkcert instalada, ou CA do domínio).
O log da subida mostra qual certificado está em uso: `docker compose logs | head`.

## 9. Comandos úteis

```bash
docker compose logs -f          # acompanhar o funcionamento
docker compose restart          # reiniciar
docker compose up -d --build    # aplicar atualizações
```
