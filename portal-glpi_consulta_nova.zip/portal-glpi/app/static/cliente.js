/* Portal - area do solicitante ("Meus chamados") */
(function () {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const CORES = { 1: "#4f9fd1", 2: "#1f7a8c", 3: "#7d5ba6", 4: "#d98e04", 5: "#2e8b57", 6: "#5d6f7d" };
  const CORES_EVENTO = { abertura: "#9aa8b3", suporte: "#1f7a8c", cliente: "#4f9fd1", solucao: "#2e8b57",
                         aprovada: "#2e8b57", recusada: "#c0392b", fechamento: "#12324a" };
  const FILTROS = [
    { id: "todos", nome: "Todos", teste: () => true },
    { id: "novos", nome: "Novos", teste: (c) => c.status === 1 },
    { id: "andamento", nome: "Em atendimento", teste: (c) => c.status === 2 || c.status === 3 },
    { id: "pendentes", nome: "Pendentes", teste: (c) => c.status === 4 },
    { id: "solucionados", nome: "Solucionados", teste: (c) => c.status === 5 },
    { id: "fechados", nome: "Fechados", teste: (c) => c.status === 6 },
  ];
  const estado = { itens: [], filtro: "todos", aberto: null, dias: 30, total: 0 };

  // todo conteudo do GLPI entra como texto, nunca como HTML
  function el(tag, classe, texto) {
    const e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto !== undefined && texto !== null) e.textContent = texto;
    return e;
  }
  function msg(alvo, tipo, texto) {
    alvo.hidden = !texto;
    alvo.className = `mensagem ${tipo}`;
    alvo.textContent = texto || "";
  }
  async function api(url, corpo) {
    const op = corpo === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) };
    const r = await fetch(url, op);
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && !url.endsWith("/login")) { telaLogin(); throw new Error(j.detail || "Entre novamente."); }
    if (!r.ok) throw new Error(j.detail || `Erro HTTP ${r.status}`);
    return j;
  }

  // ------------------------------------------------------------ telas
  function telaLogin() {
    $("#tela-login").hidden = false;
    $("#tela-chamados").hidden = true;
    document.body.classList.remove("modo-atendimento");
    $("#l-usuario").focus();
  }
  async function telaChamados(eu) {
    $("#tela-login").hidden = true;
    $("#tela-chamados").hidden = false;
    document.body.classList.add("modo-atendimento");
    $("#cl-ola").textContent = `Olá, ${eu.nome}`;
    estado.dias = eu.dias || 30;
    $("#topo-sub").textContent = `Seus chamados abertos nos últimos ${estado.dias} dias.`;
    await carregar();
  }

  async function carregar(forcar) {
    $("#cl-total").textContent = "Carregando seus chamados…";
    $("#cl-lista").innerHTML = "";
    try {
      const r = await api(forcar === true ? "/api/cliente/chamados?atualizar=true" : "/api/cliente/chamados");
      estado.itens = r.itens;
      estado.dias = r.dias;
      estado.total = r.total || r.itens.length;
      desenharFiltros();
      desenharAvisos();
      desenharLista();
    } catch (e) {
      $("#cl-total").textContent = e.message;
    }
  }

  function desenharFiltros() {
    const box = $("#cl-filtros");
    box.innerHTML = "";
    FILTROS.forEach((f) => {
      const n = estado.itens.filter(f.teste).length;
      const b = el("button", "btn" + (estado.filtro === f.id ? " ativo" : ""), `${f.nome} (${n})`);
      b.type = "button";
      b.setAttribute("aria-pressed", estado.filtro === f.id);
      b.addEventListener("click", () => { estado.filtro = f.id; desenharFiltros(); desenharLista(); });
      box.appendChild(b);
    });
  }

  function desenharAvisos() {
    const box = $("#cl-avisos");
    box.innerHTML = "";
    const pend = estado.itens.filter((c) => c.status === 4).length;
    const sol = estado.itens.filter((c) => c.status === 5).length;
    if (pend) box.appendChild(el("p", "mensagem alerta-cl", `${pend} chamado(s) aguardando a sua resposta.`));
    if (sol) box.appendChild(el("p", "mensagem ok", `${sol} chamado(s) solucionado(s) aguardando a sua avaliação.`));
  }

  function desenharLista() {
    const filtro = FILTROS.find((f) => f.id === estado.filtro);
    const itens = estado.itens.filter(filtro.teste);
    const lista = $("#cl-lista");
    lista.innerHTML = "";
    let texto = estado.itens.length
      ? `${itens.length} de ${estado.itens.length} chamado(s) dos últimos ${estado.dias} dias`
      : `Você não abriu chamados nos últimos ${estado.dias} dias.`;
    if (estado.total > estado.itens.length) {
      texto = `${itens.length} chamado(s) neste filtro. Mostrando os ${estado.itens.length} mais recentes de ${estado.total} dos últimos ${estado.dias} dias.`;
    }
    $("#cl-total").textContent = texto;
    itens.forEach((c) => {
      const li = el("li");
      const b = el("button", "item-at" + (estado.aberto === c.id ? " ativo" : ""));
      b.type = "button";
      b.dataset.id = c.id;
      b.style.setProperty("--cor-status", CORES[c.status] || "#5d6f7d");
      const l1 = el("div", "linha1");
      l1.append(el("span", "", `#${c.id} · ${c.nome_status}`), el("span", "", c.atualizacao ? `atualizado ${c.atualizacao}` : ""));
      b.append(l1, el("div", "tit", c.titulo || "(sem título)"));
      b.appendChild(el("div", "linha1", c.tecnicos.length ? `Técnico: ${c.tecnicos.join(", ")}` : "Aguardando um técnico"));
      if (c.status === 4) b.appendChild(el("div", "acao-cl", "Responda para continuar o atendimento"));
      if (c.status === 5) b.appendChild(el("div", "acao-cl ok", "Avalie a solução"));
      b.addEventListener("click", () => abrir(c.id));
      li.appendChild(b);
      lista.appendChild(li);
    });
  }

  // ------------------------------------------------------------ detalhe e acoes
  async function abrir(id) {
    estado.aberto = id;
    document.querySelectorAll(".item-at").forEach((b) => b.classList.toggle("ativo", b.dataset.id === String(id)));
    const box = $("#cl-detalhe");
    box.innerHTML = "";
    box.appendChild(el("p", "sutil-at", `Carregando o chamado ${id}…`));
    try {
      desenharDetalhe(await api(`/api/cliente/chamado/${id}`));
    } catch (e) {
      box.innerHTML = "";
      box.appendChild(el("p", "mensagem erro", e.message));
    }
    if (window.innerWidth < 960) box.scrollIntoView({ behavior: "smooth" });
  }

  function desenharDetalhe(c, aviso) {
    const box = $("#cl-detalhe");
    box.innerHTML = "";
    box.style.setProperty("--cor-status", CORES[c.status.codigo] || "#5d6f7d");
    const cab = el("div", "cabecalho-chamado");
    const t = el("div");
    t.append(el("div", "numero", `Chamado nº ${c.numero}`), el("h2", "", c.titulo || "(sem título)"));
    cab.append(t, el("span", "selo", c.status.nome));
    box.appendChild(cab);
    if (c.status.explicacao) box.appendChild(el("p", "explicacao", c.status.explicacao));
    if (aviso) box.appendChild(el("p", "mensagem ok", aviso));

    const dl = el("dl", "dados");
    const dado = (r, v) => { if (!v) return; const d = el("div"); d.append(el("dt", "", r), el("dd", "", v)); dl.appendChild(d); };
    dado("Aberto em", c.abertura);
    dado("Técnico", c.tecnicos ? c.tecnicos.join(", ") : "Aguardando um técnico");
    dado("Categoria", c.categoria);
    dado("Solucionado em", c.solucao);
    dado("Fechado em", c.fechamento);
    box.appendChild(dl);

    if (c.descricao) {
      const h = el("h3", "secao-titulo", "Descrição"); h.style.marginTop = "18px";
      box.append(h, el("p", "texto-livre", c.descricao));
    }
    if (c.historico && c.historico.length) {
      const h = el("h3", "secao-titulo", "Histórico"); h.style.marginTop = "18px";
      box.appendChild(h);
      const ol = el("ol", "linha-tempo");
      c.historico.forEach((ev) => {
        const li = el("li", `evento ${ev.tipo}`);
        li.style.setProperty("--cor-evento", CORES_EVENTO[ev.tipo] || "#9aa8b3");
        li.appendChild(el("div", "quando", ev.data));
        if (ev.autor) {
          li.append(el("div", "quem", ev.tipo === "solucao" ? `Solução registrada por ${ev.autor}` : ev.autor),
                    el("div", "balao texto-livre", ev.texto || "(sem texto)"));
        } else {
          li.appendChild(el("div", "simples", ev.texto));
        }
        ol.appendChild(li);
      });
      box.appendChild(ol);
    }

    if (c.pode_responder) box.appendChild(formResponder(c));
    if (c.pode_avaliar) box.appendChild(formAvaliar(c));
  }

  function formResponder(c) {
    const f = el("form", "resposta-at");
    f.appendChild(el("h3", "secao-titulo", "Sua resposta"));
    f.appendChild(el("p", "sutil-at", "A equipe está aguardando um retorno seu para continuar o atendimento."));
    const ta = el("textarea"); ta.required = true; ta.maxLength = 5000; ta.placeholder = "Escreva a sua resposta…";
    const res = el("div", "mensagem"); res.hidden = true;
    const bt = el("button", "btn primario", "Enviar resposta"); bt.type = "submit";
    const botoes = el("div", "botoes"); botoes.appendChild(bt);
    f.append(ta, res, botoes);
    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      bt.disabled = true; msg(res, "info", "Enviando…");
      try {
        const r = await api(`/api/cliente/chamado/${c.numero}/responder`, { texto: ta.value });
        await recarregarDepoisDaAcao(c.numero, r.message);
      } catch (err) { msg(res, "erro", err.message); bt.disabled = false; }
    });
    return f;
  }

  function formAvaliar(c) {
    const f = el("form", "resposta-at");
    f.appendChild(el("h3", "secao-titulo", "Avalie a solução"));
    f.appendChild(el("p", "sutil-at", "O problema foi resolvido? Marque uma opção."));
    const op = el("div", "opcoes");
    const opcao = (valor, titulo, ajuda) => {
      const l = el("label", "check");
      const r = el("input"); r.type = "radio"; r.name = `avaliacao-${c.numero}`; r.value = valor;
      const sp = el("span", "", titulo); sp.appendChild(el("small", "", ajuda));
      l.append(r, sp); op.appendChild(l);
      return r;
    };
    const rOk = opcao("sim", "Aprovo a solução", "O problema foi resolvido. O chamado será encerrado.");
    const rNao = opcao("nao", "Não aprovo a solução", "O problema continua. O chamado será reaberto para a equipe.");
    f.appendChild(op);
    const rot = el("label", "rotulo-cl", "Comentário (opcional)");
    const ta = el("textarea"); ta.maxLength = 5000; ta.placeholder = "Se quiser, deixe um comentário para a equipe.";
    const res = el("div", "mensagem"); res.hidden = true;
    const bt = el("button", "btn primario", "Enviar avaliação"); bt.type = "submit";
    const botoes = el("div", "botoes"); botoes.appendChild(bt);
    f.append(rot, ta, res, botoes);
    const ajustar = () => {
      const recusa = rNao.checked;
      rot.textContent = recusa ? "Por que a solução não resolveu? (obrigatório)" : "Comentário (opcional)";
      ta.required = recusa;
      ta.placeholder = recusa ? "Conte o que ainda está acontecendo." : "Se quiser, deixe um comentário para a equipe.";
      bt.textContent = recusa ? "Reabrir chamado" : rOk.checked ? "Aprovar e encerrar" : "Enviar avaliação";
    };
    rOk.addEventListener("change", ajustar);
    rNao.addEventListener("change", ajustar);
    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!rOk.checked && !rNao.checked) { msg(res, "erro", "Marque se aprova ou não aprova a solução."); return; }
      if (rNao.checked && ta.value.trim().length < 3) { msg(res, "erro", "Conte por que a solução não resolveu."); return; }
      bt.disabled = true; msg(res, "info", "Enviando…");
      try {
        const r = await api(`/api/cliente/chamado/${c.numero}/avaliar`, { aprovado: rOk.checked, comentario: ta.value });
        await recarregarDepoisDaAcao(c.numero, r.message);
      } catch (err) { msg(res, "erro", err.message); bt.disabled = false; }
    });
    return f;
  }

  async function recarregarDepoisDaAcao(id, mensagem) {
    await carregar();
    try { desenharDetalhe(await api(`/api/cliente/chamado/${id}`), mensagem); }
    catch (e) { /* lista ja atualizada */ }
  }

  // ------------------------------------------------------------ eventos
  $("#form-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const bt = $("#form-login button[type=submit]");
    bt.disabled = true; bt.textContent = "Entrando…";
    try {
      await api("/api/cliente/login", { username: $("#l-usuario").value.trim(), password: $("#l-senha").value });
      $("#l-senha").value = "";
      msg($("#l-msg"), "erro", "");
      telaChamados(await api("/api/cliente/me"));
    } catch (err) { msg($("#l-msg"), "erro", err.message); }
    finally { bt.disabled = false; bt.textContent = "Entrar"; }
  });
  $("#cl-sair").addEventListener("click", async () => { await fetch("/api/cliente/logout", { method: "POST" }); telaLogin(); });
  $("#cl-atualizar").addEventListener("click", () => carregar(true));

  fetch("/api/cliente/me").then(async (r) => (r.ok ? telaChamados(await r.json()) : telaLogin())).catch(telaLogin);
})();
