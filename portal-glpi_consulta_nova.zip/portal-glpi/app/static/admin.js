/* Area administrativa do portal */
(function () {
  "use strict";
  const $ = (s) => document.querySelector(s);

  async function api(url, corpo) {
    const op = corpo === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corpo) };
    const r = await fetch(url, op);
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && !url.endsWith("/login")) { telaLogin(); throw new Error(j.detail || "Entre novamente."); }
    if (!r.ok) throw new Error(j.detail || `Erro HTTP ${r.status}`);
    return j;
  }

  function msg(id, tipo, texto) {
    const m = $(id);
    m.hidden = !texto;
    m.className = `mensagem ${tipo}`;
    m.textContent = texto || "";
  }

  function mostrar(tela) {
    ["#tela-login", "#tela-config", "#tela-senha", "#tela-atendimento"].forEach((t) => { $(t).hidden = true; });
    document.body.classList.toggle("modo-atendimento", tela === "atendimento");
    if (tela === "login") $("#tela-login").hidden = false;
    if (tela === "config") { $("#tela-config").hidden = false; $("#tela-senha").hidden = false; }
    if (tela === "atendimento") $("#tela-atendimento").hidden = false;
    const titulos = { login: ["Área restrita", "Atendimento dos técnicos e administração do portal."],
                      config: ["Administração do portal", "Conexão com o GLPI e o que o portal público mostra."],
                      atendimento: ["Atendimento", "Seus chamados no GLPI, com resposta, pendência e solução."] };
    $("#topo-titulo").textContent = titulos[tela][0];
    $("#topo-sub").textContent = titulos[tela][1];
  }

  function telaLogin() {
    mostrar("login");
    $("#aviso-http").hidden = location.protocol !== "http:";
    $("#l-usuario").focus();
  }

  const CAMPOS = [["#c-ssl", "verify_ssl"], ["#c-descricao", "mostrar_descricao"], ["#c-historico", "mostrar_historico"],
                  ["#c-tecnico", "mostrar_tecnico"], ["#c-nomes", "mostrar_nomes"], ["#c-sla", "mostrar_sla"],
                  ["#c-email", "exigir_email"], ["#c-atendimento", "atendimento_ativo"],
                  ["#c-cliente", "cliente_ativo"]];

  function preencher(c) {
    $("#c-url").value = c.glpi_url || "";
    $("#c-app").value = ""; $("#c-user").value = "";
    $("#c-app").placeholder = c.app_token_set ? "•••••• (salvo; preencha só para trocar)" : "Configurar > Geral > API > Cliente da API";
    $("#c-user").placeholder = c.user_token_set ? "•••••• (salvo; preencha só para trocar)" : "Minhas configurações > Token da API";
    $("#c-app-limpar").checked = false;
    $("#c-timeout").value = c.timeout; $("#c-retries").value = c.retries;
    $("#c-titulo").value = c.titulo; $("#c-mensagem").value = c.mensagem;
    $("#c-limite").value = c.limite_por_minuto;
    $("#c-perfis").value = c.perfis_atendimento || "Technician";
    $("#c-perfis-cli").value = c.perfis_cliente || "Self-Service";
    $("#c-cli-dias").value = c.cliente_dias || 30;
    CAMPOS.forEach(([id, k]) => { $(id).checked = !!c[k]; });
  }

  function lerForm() {
    const d = {
      glpi_url: $("#c-url").value.trim(), app_token: $("#c-app").value.trim(), user_token: $("#c-user").value.trim(),
      limpar_app_token: $("#c-app-limpar").checked, timeout: parseInt($("#c-timeout").value, 10) || 30,
      retries: parseInt($("#c-retries").value, 10) || 2, titulo: $("#c-titulo").value.trim(),
      mensagem: $("#c-mensagem").value.trim(), limite_por_minuto: parseInt($("#c-limite").value, 10) || 10,
      perfis_atendimento: $("#c-perfis").value.trim() || "Technician",
      perfis_cliente: $("#c-perfis-cli").value.trim() || "Self-Service",
      cliente_dias: parseInt($("#c-cli-dias").value, 10) || 30,
    };
    CAMPOS.forEach(([id, k]) => { d[k] = $(id).checked; });
    return d;
  }

  async function telaConfig() {
    const c = await api("/api/admin/config");
    preencher(c);
    mostrar("config");
    if (!c.user_token_set) msg("#c-msg", "info", "Primeiro acesso: informe a URL da API e os tokens do GLPI, teste a conexão e salve.");
  }

  $("#form-login").addEventListener("submit", async (e) => {
    e.preventDefault();
    const botao = $("#form-login button[type=submit]");
    botao.disabled = true; botao.textContent = "Entrando…";
    try {
      const r = await api("/api/admin/login", { username: $("#l-usuario").value.trim(), password: $("#l-senha").value });
      $("#l-senha").value = "";
      msg("#l-msg", "erro", "");
      if (r.tipo === "admin") telaConfig(); else telaAtendimento(r);
    } catch (err) { msg("#l-msg", "erro", err.message); }
    finally { botao.disabled = false; botao.textContent = "Entrar"; }
  });

  $("#btn-testar").addEventListener("click", async () => {
    msg("#c-teste", "info", "Testando a conexão…");
    try { const r = await api("/api/admin/teste", lerForm()); msg("#c-teste", r.ok ? "ok" : "erro", r.message); }
    catch (err) { msg("#c-teste", "erro", err.message); }
  });

  $("#form-config").addEventListener("submit", async (e) => {
    e.preventDefault();
    try { preencher(await api("/api/admin/config", lerForm())); msg("#c-msg", "ok", "Configurações salvas."); }
    catch (err) { msg("#c-msg", "erro", err.message); }
  });

  $("#form-senha").addEventListener("submit", async (e) => {
    e.preventDefault();
    if ($("#s-nova").value !== $("#s-repete").value) { msg("#s-msg", "erro", "A nova senha e a repetição não são iguais."); return; }
    try {
      await api("/api/admin/senha", { atual: $("#s-atual").value, nova: $("#s-nova").value });
      ["#s-atual", "#s-nova", "#s-repete"].forEach((s) => { $(s).value = ""; });
      msg("#s-msg", "ok", "Senha alterada.");
    } catch (err) { msg("#s-msg", "erro", err.message); }
  });

  const sair = async () => { await fetch("/api/admin/logout", { method: "POST" }); telaLogin(); };
  $("#btn-sair").addEventListener("click", sair);
  $("#at-sair").addEventListener("click", sair);

  // ================================================================ atendimento (tecnicos)
  const CORES_STATUS = { 1: "#4f9fd1", 2: "#1f7a8c", 3: "#7d5ba6", 4: "#d98e04", 5: "#2e8b57", 6: "#5d6f7d" };
  const CORES_EVENTO = { abertura: "#9aa8b3", suporte: "#1f7a8c", cliente: "#4f9fd1", solucao: "#2e8b57",
                         aprovada: "#2e8b57", recusada: "#c0392b" };
  const at = { pagina: 1, total: 0, porPagina: 20, aberto: null, eu: null };

  function el(tag, classe, texto) {
    const e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto !== undefined && texto !== null) e.textContent = texto;
    return e;
  }

  async function telaAtendimento(eu) {
    mostrar("atendimento");
    $("#at-ola").textContent = `Olá, ${eu.nome}`;
    const op = await api("/api/atendimento/opcoes");
    const selT = $("#at-tecnico");
    selT.innerHTML = "";
    selT.add(new Option("Todos os técnicos", "0"));
    op.tecnicos.forEach((t) => selT.add(new Option(t.id === op.eu ? `${t.nome} (eu)` : t.nome, String(t.id))));
    selT.value = String(op.eu);
    at.eu = op.eu;
    const selS = $("#at-situacao");
    selS.innerHTML = "";
    op.situacoes.forEach((s) => selS.add(new Option(s.nome, s.id)));
    at.pagina = 1;
    carregarLista();
  }

  async function carregarLista() {
    const lista = $("#at-lista");
    lista.innerHTML = "";
    $("#at-total").textContent = "Carregando chamados…";
    try {
      const q = new URLSearchParams({ tecnico: $("#at-tecnico").value, situacao: $("#at-situacao").value, pagina: at.pagina });
      const r = await api(`/api/atendimento/chamados?${q}`);
      at.total = r.total;
      $("#at-total").textContent = r.total ? `${r.total} chamado(s)` : "Nenhum chamado nesta situação.";
      r.itens.forEach((c) => {
        const li = el("li");
        const b = el("button", "item-at");
        b.type = "button";
        if (at.aberto === c.id) b.classList.add("ativo");
        b.style.setProperty("--cor-status", CORES_STATUS[c.status] || "#5d6f7d");
        const l1 = el("div", "linha1");
        l1.append(el("span", "", `#${c.id} · ${c.nome_status}`), el("span", "", c.atualizacao ? `atualizado ${c.atualizacao}` : ""));
        b.append(l1, el("div", "tit", c.titulo || "(sem título)"));
        if (c.localizacao) b.appendChild(el("div", "local-at", `📍 ${c.localizacao}`));
        const extra = c.pendente_desde ? `Pendente desde ${c.pendente_desde}` : c.prazo ? `Prazo: ${c.prazo}` : `Aberto em ${c.abertura}`;
        b.appendChild(el("div", c.atrasado ? "linha1 atrasado" : "linha1", c.atrasado ? `${extra} (prazo excedido)` : extra));
        b.addEventListener("click", () => abrirChamado(c.id));
        li.appendChild(b);
        lista.appendChild(li);
      });
      const paginas = Math.max(1, Math.ceil(r.total / at.porPagina));
      $("#at-pag").textContent = `Página ${at.pagina} de ${paginas}`;
      $("#at-ant").disabled = at.pagina <= 1;
      $("#at-prox").disabled = at.pagina >= paginas;
    } catch (err) {
      $("#at-total").textContent = err.message;
    }
  }

  function desenharDetalhe(c) {
    const box = $("#at-detalhe");
    box.innerHTML = "";
    box.style.setProperty("--cor-status", CORES_STATUS[c.status] || "#5d6f7d");
    const cab = el("div", "cabecalho-chamado");
    const tit = el("div");
    tit.append(el("div", "numero", `Chamado nº ${c.id}`), el("h2", "", c.titulo || "(sem título)"));
    cab.append(tit, el("span", "selo", c.nome_status));
    box.appendChild(cab);

    const dl = el("dl", "dados");
    const dado = (r, v) => { if (!v) return; const d = el("div"); d.append(el("dt", "", r), el("dd", "", v)); dl.appendChild(d); };
    dado("Solicitante", c.requerentes.join(", "));
    dado("Técnico", c.tecnicos.join(", "));
    dado("Aberto em", c.abertura);
    dado("Prazo", c.prazo);
    dado("Categoria", c.categoria);
    dado("Localização", c.localizacao);
    box.appendChild(dl);

    // "Associar a mim mesmo", como no GLPI
    if (c.pode_responder && at.eu && !(c.tecnicos_ids || []).includes(at.eu)) {
      const barra = el("div", "assumir-at");
      const bt = el("button", "btn", "👤 Associar a mim mesmo");
      bt.type = "button";
      bt.title = "Adiciona você como técnico atribuído a este chamado";
      const aviso = el("span", "sutil-at", c.tecnicos.length ? "Você será adicionado junto com o técnico atual." : "Chamado ainda sem técnico.");
      bt.addEventListener("click", async () => {
        bt.disabled = true; bt.textContent = "Associando…";
        try {
          const r = await api(`/api/atendimento/chamado/${c.id}/assumir`, {});
          desenharDetalhe(r.chamado);
          const ok = el("p", "mensagem ok", r.message);
          $("#at-detalhe .dados").after(ok);
          carregarLista();
        } catch (err) {
          bt.disabled = false; bt.textContent = "👤 Associar a mim mesmo";
          aviso.textContent = err.message; aviso.className = "mensagem erro";
        }
      });
      barra.append(bt, aviso);
      box.appendChild(barra);
    }

    if (c.descricao) {
      box.appendChild(el("h3", "secao-titulo", "Descrição"));
      box.lastChild.style.marginTop = "18px";
      box.appendChild(el("p", "texto-livre", c.descricao));
    }
    const h = el("h3", "secao-titulo", "Histórico");
    h.style.marginTop = "18px";
    box.appendChild(h);
    const ol = el("ol", "linha-tempo");
    c.historico.forEach((ev) => {
      const li = el("li", `evento ${ev.tipo}${ev.privado ? " privado" : ""}`);
      li.style.setProperty("--cor-evento", CORES_EVENTO[ev.tipo] || "#9aa8b3");
      li.appendChild(el("div", "quando", ev.data));
      if (ev.autor) {
        const q = el("div", "quem", ev.tipo === "solucao" ? `Solução de ${ev.autor}` : ev.autor);
        if (ev.privado) q.appendChild(el("span", "privado-tag", "Privado"));
        li.append(q, el("div", "balao texto-livre", ev.texto || "(sem texto)"));
      } else {
        li.appendChild(el("div", "simples", ev.texto));
      }
      ol.appendChild(li);
    });
    box.appendChild(ol);

    if (!c.pode_responder) {
      box.appendChild(el("p", "mensagem info", "Chamado fechado: não aceita novas respostas."));
      return;
    }
    // ---- resposta com as "alavancas"
    const f = el("form", "resposta-at");
    f.appendChild(el("h3", "secao-titulo", "Responder"));
    const ta = el("textarea");
    ta.placeholder = "Escreva a resposta ao solicitante…";
    ta.required = true;
    f.appendChild(ta);
    const opcoes = el("div", "opcoes");
    const opcao = (titulo, ajuda) => {
      const l = el("label", "check");
      const cb = el("input"); cb.type = "checkbox";
      const sp = el("span", "", titulo);
      sp.appendChild(el("small", "", ajuda));
      l.append(cb, sp);
      opcoes.appendChild(l);
      return cb;
    };
    const cbPend = opcao("Colocar em pendência", "Aguardar o retorno do cliente. O chamado fica Pendente até ele responder.");
    const cbSol = opcao("Registrar como solução", "O chamado fica Solucionado e o solicitante aprova ou recusa.");
    const cbPriv = opcao("Privado", "Visível só para a equipe (não vale para pendência nem solução).");
    f.appendChild(opcoes);
    const res = el("div", "mensagem"); res.hidden = true;
    const botoes = el("div", "botoes");
    const enviar = el("button", "btn primario", "Enviar resposta"); enviar.type = "submit";
    botoes.appendChild(enviar);
    f.append(res, botoes);

    const ajustar = () => {
      if (cbPend.checked && cbSol.checked) { /* exclusivos: vale o ultimo marcado */ }
      cbPriv.disabled = cbPend.checked || cbSol.checked;
      if (cbPriv.disabled) cbPriv.checked = false;
      cbPriv.closest("label").classList.toggle("desligado", cbPriv.disabled);
      enviar.textContent = cbSol.checked ? "Registrar solução" : cbPend.checked ? "Enviar e deixar pendente"
        : cbPriv.checked ? "Registrar nota privada" : "Enviar resposta";
    };
    cbPend.addEventListener("change", () => { if (cbPend.checked) cbSol.checked = false; ajustar(); });
    cbSol.addEventListener("change", () => { if (cbSol.checked) cbPend.checked = false; ajustar(); });
    cbPriv.addEventListener("change", ajustar);

    f.addEventListener("submit", async (e) => {
      e.preventDefault();
      const acao = cbSol.checked ? "solucao" : cbPend.checked ? "pendente" : "resposta";
      if (acao === "solucao" && !confirm(`Registrar esta resposta como SOLUÇÃO do chamado ${c.id}?`)) return;
      enviar.disabled = true;
      res.hidden = false; res.className = "mensagem info"; res.textContent = "Enviando ao GLPI…";
      try {
        const r = await api(`/api/atendimento/chamado/${c.id}/responder`, { texto: ta.value, acao, privado: cbPriv.checked });
        desenharDetalhe(r.chamado);
        const ok = $("#at-detalhe .resposta-at .mensagem");
        if (ok) { ok.hidden = false; ok.className = "mensagem ok"; ok.textContent = r.message; }
        carregarLista();
      } catch (err) {
        res.className = "mensagem erro"; res.textContent = err.message; enviar.disabled = false;
      }
    });
    box.appendChild(f);
  }

  async function abrirChamado(id) {
    at.aberto = id;
    document.querySelectorAll(".item-at").forEach((b) => b.classList.toggle("ativo", b.textContent.startsWith(`#${id} `)));
    const box = $("#at-detalhe");
    box.innerHTML = "";
    box.appendChild(el("p", "sutil-at", `Carregando o chamado ${id}…`));
    try { desenharDetalhe(await api(`/api/atendimento/chamado/${id}`)); }
    catch (err) { box.innerHTML = ""; box.appendChild(el("p", "mensagem erro", err.message)); }
    if (window.innerWidth < 960) box.scrollIntoView({ behavior: "smooth" });
  }

  ["#at-tecnico", "#at-situacao"].forEach((s) => $(s).addEventListener("change", () => { at.pagina = 1; carregarLista(); }));
  $("#at-atualizar").addEventListener("click", carregarLista);
  $("#at-ant").addEventListener("click", () => { at.pagina -= 1; carregarLista(); });
  $("#at-prox").addEventListener("click", () => { at.pagina += 1; carregarLista(); });

  fetch("/api/admin/me").then(async (r) => {
    if (!r.ok) return telaLogin();
    const eu = await r.json();
    if (eu.tipo === "admin") telaConfig(); else telaAtendimento(eu);
  }).catch(telaLogin);
})();
