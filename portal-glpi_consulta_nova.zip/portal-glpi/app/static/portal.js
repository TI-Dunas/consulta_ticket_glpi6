/* Portal publico de consulta de chamados */
(function () {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const CORES_STATUS = { 1: "#4f9fd1", 2: "#1f7a8c", 3: "#7d5ba6", 4: "#d98e04", 5: "#2e8b57", 6: "#5d6f7d" };
  const CORES_EVENTO = { abertura: "#9aa8b3", suporte: "#1f7a8c", cliente: "#4f9fd1", solucao: "#2e8b57",
                         aprovada: "#2e8b57", recusada: "#c0392b", fechamento: "#12324a" };
  let exigirEmail = false;

  // todo conteudo vindo do GLPI entra como texto (textContent), nunca como HTML
  function el(tag, classe, texto) {
    const e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto !== undefined && texto !== null) e.textContent = texto;
    return e;
  }

  function mensagem(tipo, texto) {
    const m = $("#mensagem");
    m.hidden = !texto;
    m.className = `mensagem ${tipo}`;
    m.textContent = texto || "";
  }

  function dado(lista, rotulo, valor, classe) {
    if (!valor) return;
    const d = el("div");
    d.append(el("dt", "", rotulo), el("dd", classe || "", valor));
    lista.appendChild(d);
  }

  function mostrar(c) {
    const area = $("#resultado");
    area.innerHTML = "";
    const cor = CORES_STATUS[c.status.codigo] || "#5d6f7d";

    const principal = el("section", "cartao");
    principal.style.setProperty("--cor-status", cor);
    const cab = el("div", "cabecalho-chamado");
    const tit = el("div");
    tit.append(el("div", "numero", `Chamado nº ${c.numero}`), el("h2", "", c.titulo || "(sem título)"));
    cab.append(tit, el("span", "selo", c.status.nome));
    principal.appendChild(cab);
    if (c.status.explicacao) principal.appendChild(el("p", "explicacao", c.status.explicacao));

    const dl = el("dl", "dados");
    dado(dl, "Aberto em", c.abertura);
    dado(dl, "Última atualização", c.atualizacao);
    dado(dl, "Solucionado em", c.solucao);
    dado(dl, "Fechado em", c.fechamento);
    dado(dl, "Categoria", c.categoria);
    if (c.tecnicos) dado(dl, c.tecnicos.length > 1 ? "Técnicos" : "Técnico", c.tecnicos.join(", "));
    if (c.sla) {
      dado(dl, "Prazo de solução", c.sla.prazo);
      const classe = /excedido|Fora/.test(c.sla.situacao) ? "atrasado" : /Cumprido|Dentro/.test(c.sla.situacao) ? "cumprido" : "";
      dado(dl, "Situação do prazo", c.sla.situacao, classe);
    }
    principal.appendChild(dl);
    area.appendChild(principal);

    if (c.descricao) {
      const desc = el("section", "cartao");
      desc.append(el("h3", "secao-titulo", "Descrição"), el("p", "texto-livre", c.descricao));
      area.appendChild(desc);
    }

    if (c.historico) {
      const hist = el("section", "cartao");
      hist.appendChild(el("h3", "secao-titulo", "Histórico"));
      const ul = el("ol", "linha-tempo");
      c.historico.forEach((ev) => {
        const li = el("li", `evento ${ev.tipo}`);
        li.style.setProperty("--cor-evento", CORES_EVENTO[ev.tipo] || "#9aa8b3");
        li.appendChild(el("div", "quando", ev.data));
        if (ev.autor) {
          li.appendChild(el("div", "quem", ev.tipo === "solucao" ? `Solução registrada por ${ev.autor}` : ev.autor));
          li.appendChild(el("div", "balao texto-livre", ev.texto || "(sem texto)"));
        } else {
          li.appendChild(el("div", "simples", ev.texto));
        }
        ul.appendChild(li);
      });
      hist.appendChild(ul);
      area.appendChild(hist);
    }
    principal.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  async function consultar(e) {
    e.preventDefault();
    const numero = $("#numero").value.replace(/\D/g, "");
    const email = $("#email").value.trim();
    if (!numero) { mensagem("erro", "Informe o número do chamado (somente números)."); return; }
    if (exigirEmail && !email) { mensagem("erro", "Informe o e-mail usado na abertura do chamado."); return; }
    const botao = $("#btn-consultar");
    botao.disabled = true; botao.textContent = "Consultando…";
    mensagem("info", "Consultando o chamado…");
    $("#resultado").innerHTML = "";
    try {
      const r = await fetch("/api/consulta", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ numero, email }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { mensagem("erro", j.detail || "Não foi possível consultar agora."); return; }
      mensagem("", "");
      mostrar(j);
      history.replaceState(null, "", `/?chamado=${numero}`);
    } catch (err) {
      mensagem("erro", "Sem comunicação com o portal. Verifique a sua conexão.");
    } finally {
      botao.disabled = false; botao.textContent = "Consultar";
    }
  }

  async function iniciar() {
    $("#form-consulta").addEventListener("submit", consultar);
    $("#numero").addEventListener("input", (e) => { e.target.value = e.target.value.replace(/\D/g, ""); });
    try {
      const p = await (await fetch("/api/portal")).json();
      document.title = p.titulo;
      $("#titulo").textContent = p.titulo;
      $("#mensagem-portal").textContent = p.mensagem;
      exigirEmail = p.exigir_email;
      $("#link-cliente").hidden = !p.cliente_ativo;
      $("#campo-email").hidden = !exigirEmail;
      if (!p.configurado) mensagem("info", "O portal ainda está sendo configurado. Tente novamente mais tarde.");
    } catch (e) { /* mantem os textos padrao */ }
    const pedido = new URLSearchParams(location.search).get("chamado");
    if (pedido) {
      $("#numero").value = pedido.replace(/\D/g, "");
      if (!exigirEmail) $("#form-consulta").requestSubmit();
      else $("#email").focus();
    } else {
      $("#numero").focus();
    }
  }
  iniciar();
})();
