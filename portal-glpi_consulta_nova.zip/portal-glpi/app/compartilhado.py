"""Armazenamento compartilhado entre os processos do portal (SQLite em /data).

Com varios processos atendendo ao mesmo tempo, sessoes, limite de tentativas e cache
nao podem ficar na memoria de um processo so: o login feito num processo precisa valer
quando a proxima requisicao cair em outro.
"""
import json
import os
import secrets
import sqlite3
import time


class Compartilhado:
    def __init__(self, pasta):
        os.makedirs(pasta, exist_ok=True)
        self.caminho = os.path.join(pasta, "compartilhado.sqlite")
        con = self._con()
        try:
            con.execute("PRAGMA journal_mode=WAL")  # leituras e escritas simultaneas sem bloqueio
            con.execute("CREATE TABLE IF NOT EXISTS sessoes (sid TEXT PRIMARY KEY, tipo TEXT, dados TEXT, expira REAL)")
            con.execute("CREATE TABLE IF NOT EXISTS tentativas (chave TEXT, ts REAL)")
            con.execute("CREATE INDEX IF NOT EXISTS ix_tentativas ON tentativas(chave, ts)")
            con.execute("CREATE TABLE IF NOT EXISTS cache (chave TEXT PRIMARY KEY, valor TEXT, expira REAL)")
        finally:
            con.close()
        try:
            os.chmod(self.caminho, 0o600)
        except OSError:
            pass

    def _con(self):
        # uma conexao por operacao: simples e segura entre threads e processos
        return sqlite3.connect(self.caminho, timeout=15, isolation_level=None)

    def _executar(self, sql, params=(), um=False, todos=False):
        con = self._con()
        try:
            cur = con.execute(sql, params)
            if um:
                return cur.fetchone()
            if todos:
                return cur.fetchall()
            return cur.rowcount
        finally:
            con.close()

    # ------------------------------------------------------------ sessoes
    def criar_sessao(self, tipo, dados, horas):
        sid = secrets.token_urlsafe(32)
        self._executar("INSERT INTO sessoes VALUES (?, ?, ?, ?)", (sid, tipo, json.dumps(dados), time.time() + horas * 3600))
        if secrets.randbelow(50) == 0:  # limpeza ocasional das expiradas
            self._executar("DELETE FROM sessoes WHERE expira < ?", (time.time(),))
        return sid

    def obter_sessao(self, tipo, sid):
        if not sid:
            return None
        linha = self._executar("SELECT dados, expira FROM sessoes WHERE sid = ? AND tipo = ?", (sid, tipo), um=True)
        if not linha:
            return None
        if linha[1] < time.time():
            self._executar("DELETE FROM sessoes WHERE sid = ?", (sid,))
            return None
        return json.loads(linha[0])

    def remover_sessao(self, sid):
        if not sid:
            return None
        linha = self._executar("SELECT dados FROM sessoes WHERE sid = ?", (sid,), um=True)
        self._executar("DELETE FROM sessoes WHERE sid = ?", (sid,))
        return json.loads(linha[0]) if linha else None

    # ------------------------------------------------------------ limite de tentativas
    def permitir(self, chave, limite, janela=60):
        """True se ainda cabe uma tentativa nesta janela (vale para todos os processos)."""
        agora = time.time()
        con = self._con()
        try:
            con.execute("BEGIN IMMEDIATE")
            con.execute("DELETE FROM tentativas WHERE ts < ?", (agora - janela,))
            total = con.execute("SELECT COUNT(*) FROM tentativas WHERE chave = ?", (chave,)).fetchone()[0]
            if total >= limite:
                con.execute("COMMIT")
                return False
            con.execute("INSERT INTO tentativas VALUES (?, ?)", (chave, agora))
            con.execute("COMMIT")
            return True
        finally:
            con.close()

    # ------------------------------------------------------------ cache curto
    def cache_ler(self, chave):
        linha = self._executar("SELECT valor, expira FROM cache WHERE chave = ?", (chave,), um=True)
        if not linha or linha[1] < time.time():
            return None
        return json.loads(linha[0])

    def cache_gravar(self, chave, valor, segundos):
        self._executar("INSERT OR REPLACE INTO cache VALUES (?, ?, ?)", (chave, json.dumps(valor), time.time() + segundos))

    def cache_apagar(self, chave):
        self._executar("DELETE FROM cache WHERE chave = ?", (chave,))
