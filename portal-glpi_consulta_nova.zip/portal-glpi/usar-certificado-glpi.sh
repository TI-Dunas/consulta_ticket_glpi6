#!/bin/sh
# Usa no portal o MESMO certificado do GLPI (Apache), copiando para data/certs.
# Rode agora e sempre que o certificado do GLPI for renovado:
#     ./usar-certificado-glpi.sh
# Caminhos diferentes:  CERT=/caminho/cert.crt CHAVE=/caminho/chave.key CADEIA=/caminho/cadeia.crt ./usar-certificado-glpi.sh
set -e
cd "$(dirname "$0")"

CERT="${CERT:-/etc/pki/tls/certs/helpdesk.crt}"
CHAVE="${CHAVE:-/etc/pki/tls/private/helpdesk.key}"
CADEIA="${CADEIA:-}"            # opcional: cadeia da CA (certificados intermediarios)
NOME="${NOME:-helpdesk.grupovia.lan}"
DESTINO="data/certs"

falha() { echo "ERRO: $1" >&2; exit 1; }

[ -r "$CERT" ]  || falha "certificado não encontrado: $CERT"
[ -r "$CHAVE" ] || falha "chave não encontrada: $CHAVE"
openssl x509 -in "$CERT" -noout >/dev/null 2>&1 || falha "$CERT não é um certificado PEM válido"

# a chave precisa ser a do certificado (senao o portal nao sobe)
A=$(openssl x509 -in "$CERT" -noout -pubkey | openssl sha256)
B=$(openssl pkey -in "$CHAVE" -pubout 2>/dev/null | openssl sha256)
[ "$A" = "$B" ] || falha "a chave $CHAVE não corresponde ao certificado $CERT"

# o nome de acesso precisa estar no certificado
openssl x509 -in "$CERT" -noout -ext subjectAltName 2>/dev/null | grep -q "DNS:$NOME" \
    || falha "o certificado não contém o nome $NOME (veja: openssl x509 -in $CERT -noout -ext subjectAltName)"

# nao pode estar vencido
openssl x509 -in "$CERT" -noout -checkend 0 >/dev/null || falha "o certificado está vencido"

mkdir -p "$DESTINO"
if [ -n "$CADEIA" ]; then
    [ -r "$CADEIA" ] || falha "cadeia não encontrada: $CADEIA"
    cat "$CERT" "$CADEIA" > "$DESTINO/cert.pem.novo"
else
    cp "$CERT" "$DESTINO/cert.pem.novo"
fi
cp "$CHAVE" "$DESTINO/key.pem.novo"
chmod 600 "$DESTINO/key.pem.novo"
mv "$DESTINO/cert.pem.novo" "$DESTINO/cert.pem"
mv "$DESTINO/key.pem.novo" "$DESTINO/key.pem"

echo "Certificado copiado para o portal:"
openssl x509 -in "$DESTINO/cert.pem" -noout -subject -issuer -enddate | sed 's/^/  /'

if [ -z "$SEM_REINICIAR" ]; then
    docker compose restart
    echo "Portal reiniciado. Acesse: https://$NOME:8443"
fi
